package co.il.dmobile.myapplication_2;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

public class DataPersistencyHelper {

    public static Context Context;

    public static void StoreData(List<User> users)
    {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
        SharedPreferences.Editor editor = sp.edit();
        String json = new Gson().toJson(users );
        editor.putString("users", json);
        editor.commit();
    }

    public static List<User> LoadData()
    {
        SharedPreferences sp = PreferenceManager.getDefaultSharedPreferences(Context);
        String json = sp.getString("users",null);
        if (json != null)
        {
            Type type = new TypeToken<List<User>>(){}.getType();
            return new Gson().fromJson(json,type);
        }
        else
        {
            List<User> users = new ArrayList<User>();
            users.add(new User(R.drawable.avatar1,"Ford","1","2020","10$"));
            users.add(new User(R.drawable.avatar2,"BMW","2","2013","10$"));
            users.add(new User(R.drawable.avatar3,"Tesla","2","2012","10$"));
            users.add(new User(R.drawable.avatar4,"Toyota","4","2020","10$"));
            users.add(new User(R.drawable.avatar5,"Kia","2","2020","10$"));
            users.add(new User(R.drawable.avatar6,"Honda","3","2020","10$"));
            users.add(new User(R.drawable.avatar7,"Audi","4","2019","10$"));
            users.add(new User(R.drawable.avatar8,"Alpha","1","2015","10$"));
            return users;
        }
    }

}
