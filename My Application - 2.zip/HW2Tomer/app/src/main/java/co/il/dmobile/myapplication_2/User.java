package co.il.dmobile.myapplication_2;

import java.io.Serializable;

public class User implements Serializable {
    private int Image;
    private String Name;
    private String Email;
    private String Year;
    private String Price;

    public int getImage() {
        return Image;
    }
    public String getName() {
        return Name;
    }
    public String getEmail() {
        return Email;
    }
    public String getYear() {
        return Year;
    }
    public String getPrice() {
        return Price;
    }

    public User(int image, String name, String email, String year, String price)
    {
        this.Image = image;
        this.Name = name;
        this.Email = email;
        this.Year = year;
        this.Price = price;
    }

}
